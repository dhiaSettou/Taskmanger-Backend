package com.training.training.Controller;

import com.training.training.Entity.Category;
import com.training.training.Entity.DTO.CategoryDto;
import com.training.training.Entity.DTO.StatusDto;
import com.training.training.Entity.Mapper.CategoryMapper;
import com.training.training.Entity.Mapper.StatusMapper;
import com.training.training.Entity.Status;
import com.training.training.Repository.CategoryRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/category")
@AllArgsConstructor


public class CategoryController {
    private final CategoryRepository repository;
    private final CategoryMapper categoryMapper;


    @PostMapping(path = "/save")
    public Category addNewCategory(@RequestBody Category category) {
        repository.save(category);
        return category;
    }
    @GetMapping(path = "/get")
    private List<CategoryDto> getAll() {

        return categoryMapper.toDtos(repository.findAll());
    }


}



