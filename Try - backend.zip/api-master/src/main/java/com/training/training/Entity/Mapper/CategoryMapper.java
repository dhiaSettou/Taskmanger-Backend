package com.training.training.Entity.Mapper;

import com.training.training.Entity.Category;
import com.training.training.Entity.DTO.CategoryDto;
import com.training.training.Entity.DTO.StatusDto;
import com.training.training.Entity.Status;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")

public interface CategoryMapper {
    StatusMapper instance = Mappers.getMapper(StatusMapper.class);

    CategoryDto toDto(Category category);
    List<CategoryDto> toDtos(List<Category> categories);

    Status toEntity(CategoryDto categoryDto);

}
