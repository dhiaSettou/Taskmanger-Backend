package com.training.training.Controller;

import com.training.training.Entity.DTO.ProjectDeveloperDTO;
import com.training.training.Entity.Mapper.ProjectDeveloperMapper;
import com.training.training.Entity.Mapper.ProjectMapper;
import com.training.training.Entity.ProjectDeveloper;
import com.training.training.Repository.ProjectDeveloperRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/projectdeveloper")
@AllArgsConstructor
public class ProjectDeveloperController {
     private  final  ProjectDeveloperMapper projectDeveloperMapper ;
     private  final ProjectDeveloperRepository projectDeveloperRepository;

     @GetMapping(path = "/get")
    List<ProjectDeveloperDTO> getdata(){
       return    projectDeveloperMapper.toDtos(projectDeveloperRepository.findAll());
     }
}

